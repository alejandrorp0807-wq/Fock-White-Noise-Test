#!/usr/bin/env python3
"""EXPLORATORY follow-up conceived after inspecting first simulation outcomes.
Tests whether sparse maximum modal interaction reduces norm-test dilution.
Not part of original preregistered primary comparison.
"""
from pathlib import Path
import argparse
import numpy as np,pandas as pd
from fock_white_noise_study import coherent_features,simulation,baseline_bds

def tensor_statistics(f,q):
    n=len(f); d=f.shape[1]
    if q==3:
        M=np.einsum('ti,tj,tk->ijk',f[2:],f[1:-1],f[:-2])/(n-2)
    else:
        M=np.einsum('ti,tj,tk,tl->ijkl',f[3:],f[2:-1],f[1:-2],f[:-3])/(n-3)
    return np.array([n*np.sum(M*M)/M.size, n*np.max(M*M)])

def run(out,n,reps=35,B=99,K=4,seed=64012):
    scen=('iid_gaussian','iid_t3','xor3_noisy','xor4_noisy','ar1')
    rows=[]
    for i,name in enumerate(scen):
        rng=np.random.default_rng(np.random.SeedSequence([seed,n,i]))
        for rep in range(reps):
            x=simulation(name,n,rng);f=coherent_features(x,K)
            ob=np.concatenate([tensor_statistics(f,3),tensor_statistics(f,4)])
            count=np.zeros(4,int)
            for j in range(B):
                fp=f[rng.permutation(n)]
                values=np.concatenate([tensor_statistics(fp,3),tensor_statistics(fp,4)])
                count+=(values>=ob)
            pp=(1+count)/(B+1)
            row={'scenario':name,'n':n,'rep':rep,'q3_l2':pp[0],'q3_max':pp[1],'q4_l2':pp[2],'q4_max':pp[3]}
            rows.append(row)
        pd.DataFrame(rows).to_csv(out/f'sparse_{n}.csv',index=False)
        print(n,name,'done',flush=True)
    df=pd.DataFrame(rows)
    sm=df.groupby(['scenario','n'])[['q3_l2','q3_max','q4_l2','q4_max']].agg(lambda a:np.mean(a<=.05))
    sm.to_csv(out/f'sparse_summary_{n}.csv')
    print(sm,flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',default='.');p.add_argument('--n',type=int,default=600);p.add_argument('--reps',type=int,default=35);p.add_argument('--perms',type=int,default=99)
    a=p.parse_args();d=Path(a.out);d.mkdir(parents=True,exist_ok=True);run(d,a.n,a.reps,a.perms)
