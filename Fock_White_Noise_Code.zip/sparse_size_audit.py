#!/usr/bin/env python3
"""Independent null-size audit for exploratory sparse q4 max, designed after pilot."""
from pathlib import Path
import numpy as np,pandas as pd
from fock_white_noise_study import coherent_features,simulation
from sparse_modal_followup import tensor_statistics
out=Path(__file__).resolve().parent/'results';out.mkdir(exist_ok=True)
rows=[];N=600;B=199;R=100
for typ in ('iid_gaussian','iid_t3'):
    rng=np.random.default_rng(180124 if typ=='iid_gaussian' else 180125)
    for i in range(R):
        x=simulation(typ,N,rng);f=coherent_features(x,4)
        stat=tensor_statistics(f,4)[1];count=0
        for _ in range(B):
            count+=tensor_statistics(f[rng.permutation(N)],4)[1]>=stat
        rows.append({'scenario':typ,'n':N,'replicate':i,'p_sparse_q4_max':(1+count)/(B+1)})
    print(typ,'size',round(np.mean([r['p_sparse_q4_max']<=.05 for r in rows if r['scenario']==typ]),3),flush=True)
pd.DataFrame(rows).to_csv(out/'sparse_size_audit.csv',index=False)
