#!/usr/bin/env python3
"""Illustrative real-data diagnostic using secondary Microsoft returns in this bundle."""
from pathlib import Path
import json
import numpy as np,pandas as pd
from fock_white_noise_study import (permutation_pvalues,baseline_tests,baseline_bds,coherent_features)

def main():
    folder=Path(__file__).resolve().parent
    file=folder/'msft_oos_returns.csv'
    if not file.exists():
        print('Skipping empirical demo: msft_oos_returns.csv not found');return
    df=pd.read_csv(file)
    ret=df['return_pct'].to_numpy(float)
    std=ret/np.sqrt(df['garch_var'].to_numpy(float))
    result={}
    for label,x in [('MSFT_return',ret),('MSFT_legacy_GJR_standardized',std)]:
        result[label]={**baseline_tests(x),**baseline_bds(x),**permutation_pvalues(x,Ks=(2,4,8),perms=499,seed=3333,include_fourth=False)}
        f=coherent_features(x,4)
        d=f.shape[1]
        C=f[1:].T@f[:-1]/(len(x)-1)
        triples=np.einsum('ti,tj,tk->ijk',f[2:],f[1:-1],f[:-2])/(len(x)-2)
        flat=np.dstack(np.unravel_index(np.argsort(np.abs(triples).ravel())[-10:][::-1],triples.shape))[0]
        result[label]['top_triple_modes']=[{'indices':list(map(int,row)),'value':float(triples[tuple(row)])} for row in flat]
        result[label]['top_pair_modes']=[{'indices':list(map(int,np.unravel_index(i,C.shape))),'value':float(C.flat[i])} for i in np.argsort(np.abs(C).ravel())[-10:][::-1]]
    (folder/'empirical_demo.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
    print(json.dumps({k:{t:round(v,5) for t,v in res.items() if isinstance(v,float)} for k,res in result.items()},indent=2))
if __name__=='__main__':main()
