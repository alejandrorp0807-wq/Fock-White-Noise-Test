#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Finite coherent-state hierarchy for testing IID serial independence.

Illustrative experimental source; software for methodological research only.
Null: X_1,...,X_n are exchangeable / IID, not merely uncorrelated.
Rank transform, coherent state Fock coefficients, sample-centred features,
statistic based on 2,3,4 distinct time indices; exact Monte Carlo randomization
under IID for PRE-SPECIFIED choices.  Family-wise error uses Bonferroni.

Dependencies: numpy scipy pandas statsmodels matplotlib.
Run: OPENBLAS_NUM_THREADS=1 python fock_white_noise_study.py --suite all
"""
from __future__ import annotations
import argparse, math, time, json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import rankdata, norm, binomtest
from statsmodels.stats.diagnostic import acorr_ljungbox, het_arch
from statsmodels.tsa.stattools import bds

SCENARIOS = ('iid_gaussian','iid_t3','iid_skewed','iid_bernoulli','ar1','arch','bilinear','xor3_noisy','xor4_noisy','stochastic_volatility','variance_break')

def simulation(name: str, n: int, rng:np.random.Generator)->np.ndarray:
    if name=='iid_gaussian': return rng.normal(size=n)
    if name=='iid_t3': return rng.standard_t(3,size=n)/np.sqrt(3)
    if name=='iid_skewed': return rng.exponential(size=n)-1.
    if name=='iid_bernoulli': return rng.choice([-1.,1.],size=n)
    if name=='ar1':
        e=rng.normal(size=n+150); x=np.empty_like(e);x[0]=0.
        for t in range(1,len(e)): x[t]=.3*x[t-1]+e[t]
        return x[150:]
    if name=='arch':
        e=rng.normal(size=n+300); x=np.zeros(n+300)
        for t in range(1,len(x)): x[t]=np.sqrt(.35+.65*x[t-1]**2)*e[t]
        return x[300:]
    if name=='bilinear':
        e=rng.normal(size=n+1);return e[1:]*e[:-1]
    if name in ('xor3_noisy','xor4_noisy'):
        q=3 if name=='xor3_noisy' else 4
        m=math.ceil((n+q+5)/q)
        b=rng.choice([-1.,1.],size=(m,q-1))
        y=np.column_stack([b,np.prod(b,axis=1)]).ravel()
        start=int(rng.integers(0,q))
        return y[start:start+n]+rng.normal(scale=.15,size=n)
    if name=='stochastic_volatility':
        e=rng.normal(size=n+300);z=rng.normal(size=n+300)
        h=np.zeros(n+300)
        for t in range(1,len(h)):h[t]=.94*h[t-1]+.24*z[t]
        return (np.exp(h/2)*e)[300:]
    if name=='variance_break':
        z=rng.normal(size=n);z[n//2:]*=2.5
        return z
    raise ValueError(name)

def coherent_features(x:np.ndarray,K:int=4,bandwidth:float=1.4,
                      standardize:bool=True)->np.ndarray:
    """Sample-centered, optionally coordinate-standardized coherent-state features.
    In the unstandardized limit K->infty, the overlap kernel is Gaussian.
    Coordinate standardization changes the finite feature kernel.
    The rank map and all sample features are invariant under permutations.
    """
    x=np.asarray(x,float)
    if not np.all(np.isfinite(x)):raise ValueError('non-finite observations')
    z=norm.ppf((rankdata(x,method='average')-.5)/len(x))
    a=z/bandwidth
    f=np.empty((len(x),K+1),dtype=float)
    f[:,0]=np.exp(-.5*a*a)
    for j in range(1,K+1):f[:,j]=f[:,j-1]*a/np.sqrt(j)
    f-=f.mean(axis=0)
    if standardize:
        sd=f.std(axis=0)
        good=sd>1e-12
        f[:,good]/=sd[good]
        f[:,~good]=0
    return f

def statistics(f:np.ndarray, K:int=4, pair_max_lag:int=5,
               third:bool=True, fourth:bool=True)->np.ndarray:
    """Two/three/four-lag centered cross-moment squared Frobenius norms.
    Scaling keeps statistics O(1) under independence. Pair lags 1..5;
    triple uses consecutive (t,t-1,t-2), quadruple (t,..,t-3).
    """
    v=f[:,:K+1];n=len(v);d=v.shape[1]
    t2=0.
    for h in range(1,pair_max_lag+1):
        cov=v[h:].T@v[:-h]/(n-h)
        t2+=(n-h)*float(np.sum(cov*cov))/d**2
    if third:
        t3v=np.einsum('ti,tj,tk->ijk',v[2:],v[1:-1],v[:-2],optimize=False)/(n-2)
        t3=(n-2)*float(np.sum(t3v*t3v))/d**3
    else:t3=np.nan
    if fourth:
        t4v=np.einsum('ti,tj,tk,tl->ijkl',v[3:],v[2:-1],v[1:-2],v[:-3],optimize=False)/(n-3)
        t4=(n-3)*float(np.sum(t4v*t4v))/d**4
    else:t4=np.nan
    return np.asarray((t2,t3,t4))

def permutation_pvalues(x:np.ndarray,Ks=(2,4,8),bandwidth=1.4,perms:int=99,
                        seed:int=100,include_fourth:bool=False):
    """Permutation test. All K in same randomization, optional q=4 at K<=4.
    Primary planned test: K=4, pair+triple, Bonferroni 2.
    Other K and q4 exploratory; correct by number of selected tests.
    """
    rng=np.random.default_rng(seed)
    Ks=tuple(sorted(set(map(int,Ks))))
    f=coherent_features(x,max(Ks),bandwidth)
    f4=include_fourth
    obs=np.vstack([statistics(f,K,third=True,fourth=f4 and K<=4) for K in Ks])
    ge=np.zeros_like(obs,dtype=int)
    for b in range(perms):
        fp=f[rng.permutation(len(x))]
        null=np.vstack([statistics(fp,K,third=True,fourth=f4 and K<=4) for K in Ks])
        ge+=np.where(np.isnan(obs),0,null>=obs)
    pp=(ge+1)/(perms+1)
    pp=np.where(np.isnan(obs),np.nan,pp)
    out={}
    for i,K in enumerate(Ks):
        for j,q in enumerate((2,3,4)):
            if np.isfinite(pp[i,j]):
                out[f'fock_q{q}_K{K}']=float(pp[i,j])
        nv=pp[i,np.isfinite(pp[i])]
        out[f'fock_omni_K{K}']=min(1.,len(nv)*float(min(nv)))
    # strong white noise q2/q3 fixed K4, correct family size 2
    if 4 in Ks:
        out['primary_Fock_K4']=min(1.,2*min(out['fock_q2_K4'],out['fock_q3_K4']))
    active=pp[np.isfinite(pp)]
    out['exploratory_FWER_all']=(min(1.,len(active)*float(min(active)))
                                 if len(active)/(perms+1)<=.05 else float('nan'))
    return out

def baseline_tests(x):
    a=np.asarray(x,float)
    return {'Ljung_Box_10':float(acorr_ljungbox(a,lags=[10],return_df=True)['lb_pvalue'].iloc[0]),
            'ARCH_LM_5':float(het_arch(a-a.mean(),nlags=5)[1])}

def baseline_bds(x,max_dim=4):
    try:
        p=np.asarray(bds(np.asarray(x,float),max_dim=max_dim)[1]).ravel()
        return {'BDS_3':float(min(1.,2*min(p[:2]))),
                'BDS_4':float(min(1.,3*min(p[:3])))}
    except (FloatingPointError,ValueError,ZeroDivisionError):
        return {'BDS_3':np.nan,'BDS_4':np.nan}

def run_suite(outdir:Path,n:int=600,reps:int=50,perms:int=99,
              scenarios=SCENARIOS,Ks=(2,4,8),seed:int=20261110,
              with_bds:bool=True,with_fourth:bool=False,
              every:int=10,bandwidth:float=1.4):
    outdir.mkdir(parents=True,exist_ok=True)
    rows=[];start=time.perf_counter()
    for i,name in enumerate(scenarios):
        gen=np.random.default_rng(np.random.SeedSequence([seed,i,n]))
        for rep in range(reps):
            x=simulation(name,n,gen)
            p=permutation_pvalues(x,Ks=Ks,bandwidth=bandwidth,perms=perms,
                                  seed=int(gen.integers(0,2**32-1)),include_fourth=with_fourth)
            r={'scenario':name,'n':n,'replicate':rep,'seed_base':seed,'K_candidates':str(Ks),'bandwidth':bandwidth}
            r.update(p)
            r.update(baseline_tests(x))
            if with_bds and name!='iid_bernoulli':r.update(baseline_bds(x,max_dim=4))
            rows.append(r)
            if (rep+1)%every==0:
                elapsed=time.perf_counter()-start
                print(f'{name} n={n} {rep+1}/{reps}, total {len(rows)} {elapsed:.1f}s',flush=True)
        pd.DataFrame(rows).to_csv(outdir/f'montecarlo_{n}.csv',index=False)
    return pd.DataFrame(rows)

def summarize(df):
    keys=[k for k in df if (k.startswith(('fock_','Fock_','primary_','BDS_','Ljung_','ARCH_','exploratory_')) and k!='K_candidates')]
    out=[]
    for (scenario,n),g in df.groupby(['scenario','n'],sort=False):
        row={'scenario':scenario,'n':n,'reps':len(g)}
        for k in keys:
            available=g[k].dropna() if k in g else []
            if len(available):
                hits=int(np.sum(available<=.05))
                row[k+'_reject']=hits/len(available)
                ci=binomtest(hits,len(available)).proportion_ci(confidence_level=.95,method='wilson')
                row[k+'_CIlo']=ci.low;row[k+'_CIhi']=ci.high
        out.append(row)
    return pd.DataFrame(out)

def verify_core():
    rng=np.random.default_rng(19)
    x=rng.normal(size=101)
    f=coherent_features(x,4)
    assert np.allclose(f.mean(0),0,atol=1e-12)
    xper=x[rng.permutation(len(x))]
    fper=coherent_features(xper,4)
    assert np.allclose(np.sort(np.linalg.norm(f,axis=1)),np.sort(np.linalg.norm(fper,axis=1)))
    # Coherent state normalized and convergence to RBF overlap
    a=np.array([-.6,.3]);
    val=np.exp(-np.sum(a*a)/2)*sum((a[0]*a[1])**j/math.factorial(j) for j in range(30))
    assert abs(val-np.exp(-(a[0]-a[1])**2/2))<1e-12
    # Nontrivial pairwise independence XOR3 and triple dependence in large sample
    y=simulation('xor3_noisy',20000,rng)
    assert np.isfinite(y).all()

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--suite',choices=['main','all','quad','bandwidth'],default='all')
    parser.add_argument('--out',default='.')
    parser.add_argument('--reps',type=int,default=50)
    parser.add_argument('--perms',type=int,default=99)
    parser.add_argument('--sizes',nargs='+',type=int,default=[600,1500])
    parser.add_argument('--seed',type=int,default=20261110)
    parser.add_argument('--with-bds',action='store_true')
    args=parser.parse_args();verify_core();d=Path(args.out);d.mkdir(parents=True,exist_ok=True)
    scenarios=SCENARIOS
    if args.suite=='quad':scenarios=('iid_gaussian','iid_t3','xor3_noisy','xor4_noisy','ar1','variance_break')
    if args.suite=='bandwidth':scenarios=('iid_gaussian','ar1','xor3_noisy','xor4_noisy')
    dfs=[]
    for n in args.sizes:
        if args.suite=='bandwidth':
            for bw in (.75,1.4,2.5):
                df=run_suite(d,n,args.reps,args.perms,scenarios=scenarios,Ks=(2,4,8),seed=args.seed+int(bw*1000),with_bds=False,with_fourth=False,bandwidth=bw)
                df.to_csv(d/f'bandwidth_{n}_{bw}.csv',index=False);dfs.append(df)
        else:
            df=run_suite(d,n,args.reps,args.perms,scenarios=scenarios,Ks=(2,4) if args.suite=='quad' else (2,4,8),seed=args.seed,with_bds=args.with_bds,
                         with_fourth=(args.suite=='quad'))
            dfs.append(df)
    full=pd.concat(dfs,ignore_index=True)
    full.to_csv(d/'all_replicates.csv',index=False)
    summarize(full).to_csv(d/'summary.csv',index=False)
    with open(d/'run_config.json','w') as f:json.dump(vars(args),f,indent=2)
    print('DONE',len(full),'rows',flush=True)
