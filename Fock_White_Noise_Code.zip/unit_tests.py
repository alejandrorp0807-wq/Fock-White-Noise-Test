"""Cheap verifications for math identities and synthetic dependence structures."""
import math
import numpy as np
from scipy.stats import pearsonr
from fock_white_noise_study import coherent_features,simulation,permutation_pvalues

def run():
  rng=np.random.default_rng(2026)
  a,b=.3,-.4
  ov=math.exp(-(a*a+b*b)/2)*sum((a*b)**n/math.factorial(n) for n in range(30))
  assert np.isclose(ov,math.exp(-(a-b)**2/2),atol=1e-14)
  x=rng.standard_t(3,300)
  f=coherent_features(x,4)
  p=rng.permutation(len(x))
  assert np.allclose(f[p],coherent_features(x[p],4))
  y=simulation('xor3_noisy',120000,rng)
  z=simulation('xor4_noisy',120000,rng)
  # exact expected population moments are 1/3 and 1/4, with additive mean-zero noise
  tri=np.mean(y[2:]*y[1:-1]*y[:-2])
  quad=np.mean(z[3:]*z[2:-1]*z[1:-2]*z[:-3])
  print('XOR3 moment',tri,'XOR4 moment',quad)
  assert abs(tri-1/3)<.035
  assert abs(quad-1/4)<.035
  t=permutation_pvalues(rng.normal(size=350),Ks=(2,4),perms=99,seed=124)
  assert 0<t['primary_Fock_K4']<=1
  assert 0<t['fock_q2_K4']<=1
  print('Checks passed',t)
if __name__=='__main__':run()
