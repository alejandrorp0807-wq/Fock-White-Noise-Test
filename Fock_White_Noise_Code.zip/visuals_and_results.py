#!/usr/bin/env python3
from pathlib import Path
import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
from scipy.stats import binomtest
from fock_white_noise_study import coherent_features
BASE=Path(__file__).resolve().parent
OUT=BASE/'figs';OUT.mkdir(exist_ok=True)
DATA=BASE/'results';DATA.mkdir(exist_ok=True)
colors={'BDS':'#203965','LB':'#82909e','Fock2':'#178f87','Fock3':'#d58c33','Fock4':'#b65b70','Sign':'#7867b1','Sparse':'#9d559f'}
scenario_labels={'iid_gaussian':'Normal i.i.d.','iid_t3':'Student-t i.i.d.','iid_skewed':'Exponencial i.i.d.','iid_bernoulli':'Bernoulli i.i.d.','ar1':'AR(1)','arch':'ARCH','bilinear':'Bilineal','xor3_noisy':'XOR-3 + ruido','xor4_noisy':'XOR-4 + ruido','stochastic_volatility':'Volatilidad latente','variance_break':'Cambio de varianza'}
main=pd.concat([pd.read_csv(BASE/f'main{n}'/'all_replicates.csv') for n in (600,1500)],ignore_index=True)
# correct unusable exploratory P due min attainable p > 0.05
main['exploratory_FWER_all']=np.nan
main.to_csv(DATA/'main_replicates.csv',index=False)
quad=pd.concat([pd.read_csv(BASE/f'quad{n}'/'all_replicates.csv') for n in (600,1500)],ignore_index=True)
quad['exploratory_FWER_all']=np.nan
quad.to_csv(DATA/'quad_replicates.csv',index=False)
sparse=pd.concat([pd.read_csv(BASE/f'sparse{n}'/f'sparse_{n}.csv') for n in (600,1500)],ignore_index=True)
sparse.to_csv(DATA/'sparse_replicates.csv',index=False)
sign=pd.concat([pd.read_csv(BASE/'sign_control'/f'sign_{n}.csv') for n in (600,1500)],ignore_index=True)
sign.to_csv(DATA/'sign_replicates.csv',index=False)
main_cols=[c for c in main if c.endswith('_p') or c.startswith(('fock_','BDS_','primary_','Ljung_','ARCH_'))]
summary=[]
for (n,scen),g in main.groupby(['n','scenario']):
    d={'n':n,'scenario':scen,'replications':len(g)}
    for c in main.columns:
        if c.startswith(('fock_','BDS_','primary_','Ljung_','ARCH_')) and pd.api.types.is_numeric_dtype(g[c]):
            a=g[c].dropna()
            if len(a):
                hits=int((a<=.05).sum())
                d[c+'_rate']=hits/len(a)
                ci=binomtest(hits,len(a)).proportion_ci(.95,method='wilson')
                d[c+'_lo']=ci.low;d[c+'_hi']=ci.high
    summary.append(d)
sm=pd.DataFrame(summary)
sm.to_csv(DATA/'summary_main.csv',index=False)
quad_sm=quad.groupby(['n','scenario'])[['fock_q2_K4','fock_q3_K4','fock_q4_K4','BDS_4']].agg(lambda s:(s<=.05).mean()).reset_index()
quad_sm.to_csv(DATA/'summary_quad.csv',index=False)
sparse_sm=sparse.groupby(['n','scenario'])[['q3_l2','q3_max','q4_l2','q4_max']].agg(lambda s:(s<=.05).mean()).reset_index()
sparse_sm.to_csv(DATA/'summary_sparse.csv',index=False)
sign_sm=sign.groupby(['n','scenario'])[['sign_q3','sign_q4']].agg(lambda s:(s<=.05).mean()).reset_index()
sign_sm.to_csv(DATA/'summary_sign.csv',index=False)

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titleweight':'bold','figure.facecolor':'white','axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#314050'})

def save(name):plt.tight_layout();plt.savefig(OUT/(name+'.pdf'),bbox_inches='tight');plt.savefig(OUT/(name+'.png'),dpi=175,bbox_inches='tight');plt.close()

# Power n=1500
scens=['iid_gaussian','ar1','arch','bilinear','xor3_noisy','xor4_noisy','stochastic_volatility']
scn=sm[sm.n==1500].set_index('scenario')
keys=[('Ljung_Box_10_rate','Ljung-Box',colors['LB']),('BDS_4_rate','BDS (hasta 4)',colors['BDS']),('fock_q2_K4_rate','Fock q=2',colors['Fock2']),('fock_q3_K4_rate','Fock q=3',colors['Fock3'])]
fig,ax=plt.subplots(figsize=(11.5,4.1));pos=np.arange(len(scens));width=.19
for j,(key,label,col) in enumerate(keys):
    y=[float(scn.loc[s,key]) for s in scens]
    ax.bar(pos+(j-1.5)*width,y,width=.18,label=label,color=col)
ax.set_xticks(pos);ax.set_xticklabels([scenario_labels[s] for s in scens],rotation=22,ha='right');ax.set_ylim(0,1.08);ax.set_ylabel('Rechazos al 5 %');ax.yaxis.set_major_formatter(PercentFormatter(1.));ax.set_title('Potencia empírica por mecanismo — N=1500 (35 réplicas)');ax.axhline(.05,color='#bbbbbb',lw=.9,ls=':');ax.legend(ncol=4,fontsize=9,loc='upper left');save('potencia_1500')

fig,axes=plt.subplots(1,2,figsize=(10.5,4.0),sharey=True)
for ax,(scenario,q) in zip(axes,[('ar1','q2'),('xor3_noisy','q3')]):
    for n,c in [(600,'#1d7779'),(1500,'#d18c36')]:
        t=sm[(sm.n==n)&(sm.scenario==scenario)].iloc[0]
        ys=[t[f'fock_{q}_K{k}_rate'] for k in (2,4,8)]
        ax.plot([2,4,8],ys,marker='o',lw=2.4,label=f'N={n}',color=c)
    ax.set_xticks([2,4,8]);ax.set_ylim(0,1.05);ax.set_xlabel('Máximo modo K');ax.set_title(('AR(1): dos tiempos' if scenario=='ar1' else 'XOR-3: tres tiempos'));ax.grid(alpha=.15);ax.yaxis.set_major_formatter(PercentFormatter(1.));ax.legend()
axes[0].set_ylabel('Potencia al 5 %');fig.suptitle('Aumentar los modos no garantiza mayor potencia',fontweight='bold');save('modos_y_muestra')

fig,axes=plt.subplots(1,2,figsize=(11,4.0),sharey=True)
for ax,(n,scenario) in zip(axes,[(600,'xor3_noisy'),(1500,'xor4_noisy')]):
    s=sparse_sm[(sparse_sm.n==n)&(sparse_sm.scenario==scenario)].iloc[0]
    w=sign_sm[(sign_sm.n==n)&(sign_sm.scenario==scenario)].iloc[0]
    q=3 if scenario=='xor3_noisy' else 4
    mvals=[s[f'q{q}_l2'],s[f'q{q}_max'],w[f'sign_q{q}']]
    labels=['Fock norma L²','Fock máximo','Control de signos']
    ax.bar(labels,mvals,color=[colors['Fock3'],colors['Sparse'],colors['Sign']])
    ax.set_title(f'{scenario_labels[scenario]}, N={n}');ax.set_ylim(0,1.05);ax.yaxis.set_major_formatter(PercentFormatter(1.));ax.tick_params(axis='x',rotation=13)
axes[0].set_ylabel('Potencia al 5 %');fig.suptitle('Interacciones dispersas: el máximo modal recupera potencia',fontweight='bold');save('potencia_dispersa')

fig,ax=plt.subplots(figsize=(10.1,4.1))
null_scen=['iid_gaussian','iid_t3','iid_skewed','iid_bernoulli']
xt=np.arange(4);width=.34
for i,n in enumerate([600,1500]):
    g=sm[sm.n==n].set_index('scenario')
    y=[g.loc[s,'primary_Fock_K4_rate'] for s in null_scen]
    lo=[g.loc[s,'primary_Fock_K4_lo'] for s in null_scen]
    hi=[g.loc[s,'primary_Fock_K4_hi'] for s in null_scen]
    ax.bar(xt+(i-.5)*width,y,width,label=f'N={n}',color=['#267a7a','#bc8450'][i],alpha=.88)
    ax.errorbar(xt+(i-.5)*width,y,yerr=[np.array(y)-lo,np.array(hi)-y],fmt='none',color='#35404b',capsize=2,elinewidth=.85)
ax.axhline(.05,ls='--',lw=1,color='#be3c44',label='Nivel nominal 5 %');ax.set_xticks(xt);ax.set_xticklabels([scenario_labels[s] for s in null_scen]);ax.set_ylim(0,.22);ax.set_ylabel('Tasa de rechazo');ax.yaxis.set_major_formatter(PercentFormatter(1.));ax.set_title('Tamaño empírico y bandas Wilson (95 %) para el test primario');ax.legend(ncol=3,fontsize=9);save('tamano_bajo_iid')

bwd=[]
for bw in (.75,1.4,2.5):
    d=pd.read_csv(BASE/'bandwidth'/f'bandwidth_600_{bw}.csv')
    for scen in ('ar1','xor3_noisy'):
        sub=d[d.scenario==scen]
        for K in (2,4,8):
            key=f'fock_q{2 if scen=="ar1" else 3}_K{K}'
            bwd.append({'bandwidth':bw,'scenario':scen,'K':K,'rate':(sub[key]<=.05).mean()})
bwd=pd.DataFrame(bwd);bwd.to_csv(DATA/'bandwidth_sensitivity.csv',index=False)
fig,axes=plt.subplots(1,2,figsize=(10.3,3.7),sharey=True)
for ax,scen in zip(axes,('ar1','xor3_noisy')):
    sub=bwd[bwd.scenario==scen]
    for K,c in zip((2,4,8),('#177f88','#d58c33','#774a88')):
        gg=sub[sub.K==K];ax.plot(gg.bandwidth,gg.rate,marker='o',label=f'K={K}',color=c,lw=2)
    ax.set_ylim(0,1.04);ax.set_xticks([.75,1.4,2.5]);ax.set_xlabel('Ancho σ del estado coherente');ax.set_title('AR(1), q=2' if scen=='ar1' else 'XOR-3 con ruido, q=3');ax.grid(alpha=.13);ax.legend(ncol=3,fontsize=8)
axes[0].set_ylabel('Rechazo al 5 %');axes[0].yaxis.set_major_formatter(PercentFormatter(1.));save('sensibilidad_ancho')

sample=pd.read_csv(BASE/'msft_oos_returns.csv')
ret=sample.return_pct.to_numpy();std=ret/np.sqrt(sample.garch_var.to_numpy())
fig,axes=plt.subplots(1,2,figsize=(9.4,3.8))
for ax,x,title in zip(axes,(ret,std),('Retornos originales','Innovaciones GJR reescaladas')):
    f=coherent_features(x,4);C=f[1:].T@f[:-1]/(len(f)-1)
    im=ax.imshow(C,cmap='RdBu_r',vmin=-.17,vmax=.17,origin='lower')
    ax.set_xlabel('Modo en t-1');ax.set_ylabel('Modo en t');ax.set_xticks(range(5));ax.set_yticks(range(5));ax.set_title(title)
fig.colorbar(im,ax=axes,fraction=.028,pad=.02,label='Covarianza modal');save('aplicacion_microsoft')

print('WROTE',len(list(OUT.glob('*.pdf'))),'FIGURES',len(sm),'SCENARIOS')
