#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
D=Path(__file__).resolve().parent
sm=pd.read_csv(D/'results'/'summary_main.csv');ss=pd.read_csv(D/'results'/'summary_sparse.csv');sg=pd.read_csv(D/'results'/'summary_sign.csv');tm=pd.read_csv(D/'timings.csv')
labels={'iid_gaussian':'Normal i.i.d.','iid_t3':'Student-t i.i.d.','iid_skewed':'Exponencial i.i.d.','iid_bernoulli':'Bernoulli i.i.d.','ar1':'AR(1)','arch':'ARCH','bilinear':'Bilineal','xor3_noisy':'XOR-3 + ruido','xor4_noisy':'XOR-4 + ruido','stochastic_volatility':'Volatilidad latente','variance_break':'Cambio de escala'}
order=list(labels)
def pct(x):return f'{100*x:.0f}\\%' if pd.notna(x) else '---'
def table_primary(n):
    d=sm[sm.n==n].set_index('scenario')
    out=[r'\resizebox{\textwidth}{!}{%',r'\begin{tabular}{lrrrrrr}',r'\toprule',r'Escenario & Ljung--Box & ARCH--LM & BDS(4) & Fock $T_2$ & Fock $T_3$ & Fock primario \\',r'\midrule']
    for scen in order:
        r=d.loc[scen]
        cells=[labels[scen]]+[pct(r.get(k+'_rate',float('nan'))) for k in ['Ljung_Box_10','ARCH_LM_5','BDS_4','fock_q2_K4','fock_q3_K4','primary_Fock_K4']]
        out.append(' & '.join(cells)+r' \\')
    out.extend([r'\bottomrule',r'\end{tabular}}'])
    return '\n'.join(out)
def table_sparse():
    out=[r'\resizebox{\textwidth}{!}{%',r'\begin{tabular}{llrrrr}',r'\toprule',r'Escenario & $N$ & $L^2$ modal & Máximo modal & Signos dirigido & BDS(4) \\',r'\midrule']
    for n in [600,1500]:
        for scen in ['xor3_noisy','xor4_noisy']:
            q=3 if scen=='xor3_noisy' else 4
            s=ss[(ss.n==n)&(ss.scenario==scen)].iloc[0];g=sg[(sg.n==n)&(sg.scenario==scen)].iloc[0]
            # BDS table comes from main study, with separate replicates
            m=sm[(sm.n==n)&(sm.scenario==scen)].iloc[0]
            cells=[labels[scen],str(n),pct(s[f'q{q}_l2']),pct(s[f'q{q}_max']),pct(g[f'sign_q{q}']),pct(m['BDS_4_rate'])]
            out.append(' & '.join(cells)+r' \\')
    out.extend([r'\bottomrule',r'\end{tabular}}',r'\par\smallskip\footnotesize\emph{Nota:} BDS proviene del experimento principal, con otras réplicas y distinta selección de muestras; las columnas no constituyen una prueba emparejada de superioridad.'])
    return '\n'.join(out)
def table_modes():
    out=[r'\begin{center}\small',r'\begin{tabular}{llrrrrrr}',r'\toprule',r'Escenario & $N$ & $T_2(K2)$ & $T_2(K4)$ & $T_2(K8)$ & $T_3(K2)$ & $T_3(K4)$ & $T_3(K8)$ \\',r'\midrule']
    for scen in ('ar1','xor3_noisy','arch','iid_gaussian'):
        for n in [600,1500]:
            r=sm[(sm.n==n)&(sm.scenario==scen)].iloc[0]
            out.append(' & '.join([labels[scen],str(n)]+[pct(r.get(f'fock_q{q}_K{k}_rate')) for q in [2,3] for k in [2,4,8]])+r' \\')
    out.extend([r'\bottomrule',r'\end{tabular}',r'\end{center}'])
    return '\n'.join(out)
def table_timings():
    out=[r'\begin{tabular}{rll}',r'\toprule',r'$N$ & Procedimiento & Tiempo (s) \\',r'\midrule']
    for n in [600,1500,2500]:
        for _,r in tm[tm.n==n].iterrows():
            name={'Ljung_Box+ARCH':'Ljung--Box y ARCH--LM','BDS_dim4':'BDS hasta dim. 4','Fock_q2_q3_K2468_B199':'Fock q2/q3; $K=2,4,8$; 199 perm.','Fock_q2_q3_q4_K24_B199':'Fock q2/q3/q4; $K=2,4$; 199 perm.'}[r['method']]
            out.append(f"{n} & {name} & {r['median_seconds']:.3f}"+r' \\')
        out.append(r'\addlinespace')
    out.extend([r'\bottomrule',r'\end{tabular}'])
    return '\n'.join(out)
s=(D/'manuscrito_base.tex').read_text()
for tag,value in {'%%TABLE_MAIN600%%':table_primary(600),'%%TABLE_MAIN1500%%':table_primary(1500),'%%TABLE_SPARSE%%':table_sparse(),'%%TABLE_MODES%%':table_modes(),'%%TABLE_TIMING%%':table_timings()}.items():
    assert tag in s,tag
    s=s.replace(tag,value)
(D/'manuscrito.tex').write_text(s)
print('WROTE',D/'manuscrito.tex',len(s),'chars')
