# Test exploratorio de independencia temporal mediante estados coherentes de Fock

**Fecha:** 10 de noviembre de 2026. **Tipo:** simulación Monte Carlo, no estudio de datos históricos.

## Objetivo y alcance

Hipótesis nula: la secuencia `x_t` es **independiente e idénticamente distribuida** (ruido blanco fuerte). Este test **no** es un test puro de ruido blanco débil (ausencia de autocorrelación con varianza constante): los procesos ARCH y bilineales pueden pasar un test de covarianza y, correctamente, fallar el de independencia.

Se estudian relaciones entre modos de estados coherentes de Fock y hasta tres tiempos distintos, frente a Ljung–Box, ARCH-LM y BDS. **No** se presenta el método como nuevo en sentido estadístico: la base coherente es equivalente a características de kernels gaussianos en su límite completo; existen AutoHSIC y tests de bicorrelaciones de Hinich.

## Construcción

1. Transformar las observaciones por sus rangos a `z_t = Phi^-1((rank(x_t)-0.5)/N)`. La transformacion de rangos evita exigir colas gaussianas y preserva la independencia bajo transformaciones medibles. En muestras con empates se usan rangos medios.
2. Mapear a estado coherente real `alpha_t=z_t/sigma`, sigma=1.4, con `f_n(x)=exp(-alpha^2/2)*alpha^n/sqrt(n!)`, n=0..K. Se centran y normalizan las columnas. K=2,4,8.
3. Calcular matrices de correlación modal para retardos 1..5: `C_nm(lag)=mean(f_n(t)f_m(t-lag))`.
4. Calcular tensores de tres tiempos con parejas 1<=a<b<=3: `D_nmp(a,b)=mean(f_n(t)f_m(t-a)f_p(t-b))`.
5. Estadísticos: `T2=sum_lag (N-lag)||C||_F^2/(K+1)^2`; `T3=sum_{a<b} (N-b)||D||_F^2/(K+1)^3`. Los features utilizados en estas expresiones están centrados y estandarizados.
6. Calibrar ambos test mediante **99 permutaciones temporales** (`p = (1+#(T_perm >= T_obs))/100`); combinar con Bonferroni si se desea un test conjunto. El test permutacional es válido bajo la nula i.i.d. No se reclama validez como prueba de no-correlación bajo procesos dependientes.

El solapamiento entre las parejas temporales impide asumir una distribucion chi-cuadrado simple, razón para utilizar permutación.

## Escenarios simulados

- `iid_normal`: normal independiente, control nulo.
- `iid_t3`: Student-t con 3 grados de libertad independiente, control nulo de colas pesadas.
- `ar1`: `x_t=0.3 x_{t-1}+epsilon_t`.
- `arch`: `h_t=0.35+0.65 x_{t-1}^2`, `x_t=sqrt(h_t)epsilon_t`, con periodo de calentamiento.
- `bilinear`: `x_t=epsilon_t epsilon_{t-1}`, con autocorrelacion teórica nula pero dependencia no lineal.
- `xor_triplets`: bloques `A, B, AB` con A y B Rademacher independientes, desplazamiento de fase aleatorio para estacionariedad; **todos los pares son independientes, pero algunas ternas no lo son**. Proceso discreto: las asintóticas del BDS con muchos empates requieren precaución; el test por permutación sigue siendo válido bajo i.i.d.

## Tamaños, semillas y resultados

- N=500: 90 realizaciones independientes por escenario.
- N=1500: 45 realizaciones independientes por escenario.
- Todos los Fock tests: 99 permutaciones por realización, modos K=2,4,8, retardos hasta 5 y triples hasta 3.
- BDS: 90 realizaciones por escenario y N, en **otra corrida independiente** con iguales distribuciones, `statsmodels.bds(max_dim=3)`; los resultados se comparan como tasas de rechazo, **no de forma pareada**.
- Los rechazos se evalúan con `p<=0.05` para todos los tests. La calibración permutacional produce p-valores discretos en pasos de 0.01; el criterio inclusivo alcanza exactamente el umbral nominal del 5 %.

Resulta especialmente claro en el proceso `xor_triplets`: K=4 con correlaciones de dos tiempos rechaza aproximadamente el 4 % (N=500) y el 0 % (N=1500), mientras la interaccion de tres tiempos rechaza el 100 % en ambas muestras. BDS también rechaza el 100 %, por tanto el test no demuestra superioridad de Fock sobre BDS.

**Advertencias:** La potencia depende de ancho del estado coherente, K, longitud de las correlaciones y tipo de alternativas. El contraste de independencia i.i.d. no equivale a probar el caos determinista, ni establece utilidad de pronóstico. La prueba depende de la elección a priori de hiperparámetros; optimizarlos sobre la muestra evaluada exige recalibración de toda la búsqueda.

## Reproducción

```bash
python -m pip install -r requirements.txt
# simulaciones N=500, 90 réplicas
OPENBLAS_NUM_THREADS=1 python white_noise_fock.py --reps 90 --perms 99 --lengths 500 --out .
# simulaciones N=1500, 45 réplicas, una serie cada vez
for s in iid_normal iid_t3 ar1 arch bilinear xor_triplets; do
  OPENBLAS_NUM_THREADS=1 python run_scenario.py "$s" 1500 45 99
done
# comparación con BDS (otra corrida independiente)
OPENBLAS_NUM_THREADS=1 python bds_comparison.py
# agregar y graficar
OPENBLAS_NUM_THREADS=1 python finalize.py
```

`finalize.py` acepta la salida del script principal para 500 y los seis archivos `sim_{scenario}_1500.csv`. El paquete adjunta además los resultados finales para facilitar auditoría.

## Referencias científicas relevantes

- Li, Xu y Zhou (2026), *Testing for Serial Independence via Auto Hilbert-Schmidt Independence Criterion*, arXiv:2605.22025.
- Hinich (1996), *Testing for dependence in the input to a linear time series model*, Journal of Nonparametric Statistics.
- Baum, Hurn y Lindsay (2021), *The BDS test of independence*, Stata Journal.
- Tiwari et al. (2022), *Kernel method based on non-linear coherent states in quantum feature space*, J. Phys. A.
- Dalla, Giraitis y Phillips (2019, 2022), *Robust Tests for White Noise and Cross-Correlation*.
