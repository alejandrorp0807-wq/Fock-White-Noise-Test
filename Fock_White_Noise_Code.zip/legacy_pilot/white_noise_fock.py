#!/usr/bin/env python3
"""Finite coherent-state Fock serial-dependence test.

Null: observations are iid (strong white noise).  Permutation calibration is
conditional exact under iid/exchangeability for predetermined hyperparameters.
This is closely related to nonlinear kernel independence / AutoHSIC tests.
"""
import argparse, math, time
from pathlib import Path
import numpy as np
from scipy.stats import rankdata, norm
from statsmodels.stats.diagnostic import acorr_ljungbox, het_arch


def fock_features(x, K=8, sigma=1.4, rank_gaussianize=True):
    """Features <n|alpha(z)> for real coherent state alpha=z/sigma, n=0..K."""
    x=np.asarray(x, dtype=float)
    if rank_gaussianize:
        u = (rankdata(x, method='average') - 0.5) / len(x)
        z = norm.ppf(u)
    else:
        z=(x-np.mean(x))/(np.std(x)+1e-12)
    a=z/sigma
    f=np.empty((len(x), K+1),float)
    f[:,0]=np.exp(-a*a/2)
    for j in range(1,K+1):
        f[:,j]=f[:,j-1]*a/math.sqrt(j)
    f-=f.mean(0)
    sd=f.std(0)
    f[:,sd>1e-10]/=sd[sd>1e-10]
    f[:,sd<=1e-10]=0
    return f


def fock_statistics(f, K=4, max_lag=5, triple_lag=3):
    n=len(f); f=f[:,:K+1]; d=f.shape[1]
    p=0.
    for lag in range(1,max_lag+1):
        C=(f[lag:].T@f[:-lag])/(n-lag)
        p+=(n-lag)*np.sum(C*C)/(d*d)
    q=0.
    for a in range(1,triple_lag):
        for b in range(a+1,triple_lag+1):
            T=np.einsum('ti,tj,tk->ijk',f[b:],f[b-a:-a],f[:-b],optimize=False)/(n-b)
            q+=(n-b)*np.sum(T*T)/(d**3)
    return p,q


def test_fock(x, K=4, max_lag=5, triple_lag=3, B=199, seed=12345):
    f=fock_features(x,K)
    observed=np.array(fock_statistics(f,K,max_lag,triple_lag))
    rng=np.random.default_rng(seed)
    perms=np.empty((B,2))
    for i in range(B):
        perms[i]=fock_statistics(f[rng.permutation(len(f))],K,max_lag,triple_lag)
    pval=(1+(perms>=observed).sum(0))/(B+1)
    return {'pair_stat':float(observed[0]),'triple_stat':float(observed[1]),
            'pair_p':float(pval[0]),'triple_p':float(pval[1]),
            'omnibus_p':float(min(1,2*min(pval)))}


def simulate(kind,n,rng):
    if kind=='iid_normal': return rng.normal(size=n)
    if kind=='iid_t3': return rng.standard_t(df=3,size=n)/np.sqrt(3)
    if kind=='ar1':
        e=rng.normal(size=n+100); x=np.zeros(len(e))
        for t in range(1,len(e)): x[t]=0.3*x[t-1]+e[t]
        return x[100:]
    if kind=='arch':
        e=rng.normal(size=n+300); x=np.zeros(len(e)); h=np.ones(len(e))
        for t in range(1,len(e)):
            h[t]=0.35+0.65*x[t-1]**2
            x[t]=np.sqrt(h[t])*e[t]
        return x[300:]
    if kind=='bilinear':
        e=rng.normal(size=n+1)
        return e[1:]*e[:-1]
    if kind=='xor_triplets':
        m=(n+10)//3 + 3
        a=rng.choice([-1.,1.],size=m); b=rng.choice([-1.,1.],size=m)
        x=np.stack([a,b,a*b],axis=1).ravel()
        off=int(rng.integers(0,3))
        return x[off:off+n].copy()
    if kind=='logistic4':
        # invariant stationary measure can be generated via random initial phase.
        # Doubling map phase avoids floating overflow/absorption into finite orbit.
        x=np.empty(n); theta=rng.random()
        for t in range(n):
            theta=(2*theta)%1
            x[t]=0.5-np.cos(2*np.pi*theta)/2
        return x
    raise ValueError(kind)


def compare(kind,n,reps=50,B=99,Ks=(2,4,8),seed=20261110):
    import pandas as pd
    rng=np.random.default_rng(seed)
    rows=[]
    t0=time.perf_counter()
    for rep in range(reps):
        x=simulate(kind,n,rng)
        f=fock_features(x,max(Ks))
        obs=np.array([fock_statistics(f,K) for K in Ks]) # shape nK,2
        pp=np.zeros_like(obs,dtype=int)
        for b in range(B):
            fp=f[rng.permutation(n)]
            nul=np.array([fock_statistics(fp,K) for K in Ks])
            pp+=(nul>=obs)
        pv=(1+pp)/(B+1)
        lb=float(acorr_ljungbox(x,lags=[10],return_df=True)['lb_pvalue'].iloc[0])
        arch=float(het_arch(x-np.mean(x),nlags=5)[1])
        d={'scenario':kind,'n':n,'replicate':rep,'ljung_box_p':lb,'arch_lm_p':arch}
        for i,K in enumerate(Ks):
            d[f'fock_pair_K{K}_p']=pv[i,0]
            d[f'fock_triple_K{K}_p']=pv[i,1]
            d[f'fock_bonf_K{K}_p']=min(1.,2*min(pv[i]))
        rows.append(d)
        if (rep+1)%10==0: print(kind,n,rep+1,'/',reps,'seconds',round(time.perf_counter()-t0,1),flush=True)
    return pd.DataFrame(rows)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--reps',type=int,default=45)
    parser.add_argument('--perms',type=int,default=99)
    parser.add_argument('--lengths',type=int,nargs='+',default=[500,1500])
    parser.add_argument('--out',type=str,default='.')
    args=parser.parse_args()
    import pandas as pd
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    scenarios=['iid_normal','iid_t3','ar1','arch','bilinear','xor_triplets']
    allrows=[]
    for n in args.lengths:
        for i,k in enumerate(scenarios):
            df=compare(k,n,reps=args.reps,B=args.perms,seed=17+n*100+i)
            allrows.append(df)
            pd.concat(allrows,ignore_index=True).to_csv(out/'simulation_replicates.csv',index=False)
    df=pd.concat(allrows,ignore_index=True)
    fields=[c for c in df if c.endswith('_p')]
    group=df.groupby(['scenario','n'])
    summ=group[fields].agg(lambda s:np.mean(s<0.05)).reset_index()
    summ.to_csv(out/'simulation_power.csv',index=False)
    print(summ.to_string(index=False))
