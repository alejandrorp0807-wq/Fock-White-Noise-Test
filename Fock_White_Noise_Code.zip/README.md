# Test de independencia temporal mediante estados de Fock

**Estado:** borrador técnico reproducible / prepublicación exploratoria. **Fecha:** 10-11-2026.

Este paquete reúne el PDF (`Manuscrito_Test_Fock_Ruido_Blanco.pdf`), su código fuente LaTeX y un estudio Monte Carlo reproducible en Python. **No es un test de ruido blanco débil**; contrasta independencia temporal i.i.d. frente a formas de dependencia lineal y no lineal.

## Resultados y conclusión

El test de Fock de dos tiempos detecta AR(1), ARCH, volatilidad persistente y dependencia bilineal. El tensor de tres tiempos detecta dependencia de tipo XOR3 no visible por correlaciones entre pares. Los test de máximo modal recuperan potencia frente a dependencias dispersas XOR3/XOR4, pero son variantes EXPLORATORIAS. La evidencia no apoya afirmar superioridad frente a BDS y controles dirigidos sencillos; el uso de estados coherentes es formalmente equivalente a una aproximación finita a un kernel gaussiano.

Con 35 realizaciones y N=1500, Fock T2 (K=4) rechaza el 100% de AR1, ARCH y bilineal; Fock T3 rechaza el 100% de XOR3 con ruido, frente al ~3% de Ljung-Box. BDS también rechaza el 100% de XOR3/XOR4, por lo que no hay victoria específica de Fock. Véanse los intervalos Wilson en el PDF.

## Instalación

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
python -m pip install -r requirements.txt
```

Para usar un solo test:

```python
import numpy as np
from fock_white_noise_study import permutation_pvalues
rng = np.random.default_rng(123)
x = rng.normal(size=1200)
out = permutation_pvalues(x, Ks=(2, 4, 8), bandwidth=1.4, perms=499, seed=1234)
print('p global K4 (T2 y T3):', out['primary_Fock_K4'])
print('p T2:', out['fock_q2_K4'], 'p T3:', out['fock_q3_K4'])
```

La prueba principal utiliza K=4, ancho 1.4, 5 retardos para dos tiempos y tiempos consecutivos en T3. Hay que decidir las características **antes** de observar el resultado. La búsqueda posterior entre K, q, σ o retardos exige corrección múltiple que debe recalibrarse. Para correr un omnibus entre seis tests con Bonferroni, **99 permutaciones no bastan** para poder rechazar al 5% (p mínimo ×6 = .06). Se requieren al menos 199 permutaciones o un método de máximo permutacional conjunto.

## Reproducción del estudio principal

Desde esta misma carpeta:

```bash
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python fock_white_noise_study.py --suite main --out main600  --sizes 600 --reps 55 --perms 99 --with-bds
python fock_white_noise_study.py --suite main --out main1500 --sizes 1500 --reps 35 --perms 99 --with-bds
python fock_white_noise_study.py --suite quad --out quad600  --sizes 600 --reps 30 --perms 99 --with-bds
python fock_white_noise_study.py --suite quad --out quad1500 --sizes 1500 --reps 20 --perms 99 --with-bds
python sparse_modal_followup.py --n 600 --reps 35 --perms 199 --out sparse600
python sparse_modal_followup.py --n 1500 --reps 20 --perms 199 --out sparse1500
python higher_order_controls.py --n 600 --reps 55 --perms 199 --out sign_control
python higher_order_controls.py --n 1500 --reps 35 --perms 199 --out sign_control
python fock_white_noise_study.py --suite bandwidth --out bandwidth --sizes 600 --reps 25 --perms 99
python empirical_demo.py
python timing_bench.py
python visuals_and_results.py
```

Los archivos completos ya se encuentran bajo `results/`. Si ejecutas todo desde cero, guarda los resultados de la nueva ejecución en un directorio independiente; el código `visuals_and_results.py` espera la estructura de carpetas indicada.

El estudio de ancho utiliza tres valores (0.75, 1.4 y 2.5) y una misma carpeta `bandwidth`, pero guarda un CSV independiente por ancho. Los resultados de `empirical_demo.py` usan una subserie de retornos de Microsoft conservada de un experimento anterior: no es una fuente de mercado descargada y auditada nuevamente.

## Estructura de archivos

- `fock_white_noise_study.py` : test central (T2, T3, T4), calibración permutacional, simuladores, comparación LB/ARCH/BDS.
- `sparse_modal_followup.py` : estadístico de máximo de coeficientes modales (comparación exploratoria).
- `higher_order_controls.py` : comparación dirigida con productos de signos, calibrada por permutaciones.
- `sparse_size_audit.py` : auditoría adicional del tamaño del máximo de cuarto orden, bajo dos nulas independientes.
- `empirical_demo.py` : diagnóstico ilustrativo sobre los retornos y las innovaciones de GJR.
- `timing_bench.py`, `visuals_and_results.py` : coste y gráficos.
- `unit_tests.py` : validación de equivalencia kernel y generadores sintéticos.
- `results/` : CSV de cada réplica y resúmenes; ver `summary_main.csv` y `summary_sparse.csv`.
- `figs/` : seis figuras PDF/PNG.
- `manuscrito.tex` : fuente compilable del artículo.
- `msft_oos_returns.csv` : 2481 días de datos secundarios, incluidos para replicar el diagnóstico.

## Auditoría adicional del tamaño

Se han probado 100 series normales i.i.d. y 100 Student-t3 i.i.d. con N=600, K=4, q=4 máximo modal y 199 permutaciones. Las tasas de rechazo fueron 3 % y 7 %, con intervalos Wilson que incluyen 5 %. Ver `results/sparse_size_audit.csv`.

## Piloto previo

El directorio `legacy_pilot/` incluye el test inicial y su potencia Monte Carlo. En ese piloto, XOR3 era discreto sin ruido y se usaban varias ternas de retardos; por eso sus cifras no se pueden comparar directamente con las del estudio nuevo, cuyo XOR3 lleva ruido y usa la terna consecutiva.

## Principales limitaciones

1. Pocos escenarios naturales y 35--55 réplicas por celda: incertidumbre significativa de Monte Carlo.
2. La potencia depende de K, σ, q y los retardos elegidos.
3. Las variantes de máximo fueron concebidas después de observar la primera batería; requieren estudio confirmatorio independiente.
4. No se demostró superioridad de potencia ni de tiempo frente a BDS y tests de kernels existentes.
5. La calibración por permutaciones es exacta bajo i.i.d./intercambiabilidad de la secuencia observada y características elegidas a priori; no se aplica automáticamente a residuos estimados ni a series con heterogeneidad temporal.

## Originalidad

El límite de estados coherentes corresponde a un kernel gaussiano; tests de independencia con kernels (HSIC, dHSIC y AutoHSIC) están publicados. Este manuscrito presenta una exploración de la *interpretabilidad modal y la jerarquía temporal*, pero aún no establece un nuevo test estadístico superior que cumpla requisitos rigurosos de revista. Se recomienda compartirlo como **preprint exploratorio** o informe abierto, no como demostración de superioridad.
