#!/usr/bin/env python3
"""Simple sign-interaction benchmark, reusing the SAME streams as main study.
Tests q=3 and q=4 sign-product dependence with permutation calibration;
these tests are targeted controls, not general omnibus independence tests.
"""
from pathlib import Path
import argparse
import numpy as np,pandas as pd
from fock_white_noise_study import simulation,SCENARIOS

def sign_stat(s,q):
    w=s.copy()
    for h in range(1,q):w=w[h:]*s[:len(s)-h] if h==1 else w[1:]*s[:len(s)-h]
    return abs(np.mean(w))

def exact_formula(s,q):
    prod=np.ones(len(s)-q+1)
    for h in range(q):prod*=s[q-1-h:len(s)-h]
    return abs(float(prod.mean()))

def run(n=600,reps=55,B=199,out='.'):
    rows=[];out=Path(out);out.mkdir(parents=True,exist_ok=True)
    for i,name in enumerate(SCENARIOS):
        gen=np.random.default_rng(np.random.SeedSequence([20261110,i,n]))
        for rep in range(reps):
            x=simulation(name,n,gen)
            gen.integers(0,2**32-1) # Consume same stream step as main experiment
            s=np.sign(x-np.median(x));s-=s.mean()
            obs=np.array([exact_formula(s,3),exact_formula(s,4)])
            counts=np.zeros(2,int)
            rng=np.random.default_rng(300000+n*100+rep*11+i)
            for b in range(B):
                sp=s[rng.permutation(n)]
                counts+=(np.array([exact_formula(sp,3),exact_formula(sp,4)])>=obs)
            p=(counts+1)/(B+1)
            rows.append({'scenario':name,'n':n,'replicate':rep,'sign_q3':p[0],'sign_q4':p[1]})
        print(n,name,'done',flush=True)
    df=pd.DataFrame(rows)
    df.to_csv(out/f'sign_{n}.csv',index=False)
    print(df.groupby(['scenario','n'])[['sign_q3','sign_q4']].agg(lambda s:(s<=.05).mean()).to_string())
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--n',type=int,default=600);p.add_argument('--reps',type=int,default=55);p.add_argument('--perms',type=int,default=199);p.add_argument('--out',default='.')
    a=p.parse_args();run(a.n,a.reps,a.perms,a.out)
