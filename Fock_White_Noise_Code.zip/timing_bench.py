#!/usr/bin/env python3
import time,json
from pathlib import Path
import numpy as np
from fock_white_noise_study import simulation,permutation_pvalues,baseline_tests,baseline_bds
from sparse_modal_followup import tensor_statistics
from fock_white_noise_study import coherent_features
OUT=Path(__file__).resolve().parent
rng=np.random.default_rng(8329)
rows=[]
for n in (600,1500,2500):
 x=simulation('arch',n,rng)
 tests=[('Ljung_Box+ARCH', lambda:baseline_tests(x)),
        ('BDS_dim4',lambda:baseline_bds(x)),
        ('Fock_q2_q3_K2468_B199',lambda:permutation_pvalues(x,Ks=(2,4,8),perms=199,seed=887,include_fourth=False)),
        ('Fock_q2_q3_q4_K24_B199',lambda:permutation_pvalues(x,Ks=(2,4),perms=199,seed=887,include_fourth=True))]
 for name,fn in tests:
  times=[]
  for _ in range(3):
   t=time.perf_counter();fn();times.append(time.perf_counter()-t)
  rows.append({'n':n,'method':name,'median_seconds':float(np.median(times)),'min_seconds':float(np.min(times))})
  print(n,name,round(float(np.median(times)),3),flush=True)
import pandas as pd
pd.DataFrame(rows).to_csv(OUT/'timings.csv',index=False)
